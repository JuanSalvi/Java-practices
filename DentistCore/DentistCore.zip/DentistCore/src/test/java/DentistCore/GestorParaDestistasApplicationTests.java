package DentistCore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestorParaDestistasApplicationTests {

	@Test
	void contextLoads() {
	}

}
